# Web Development Lab

Six experiments: HTML, CSS, JavaScript, Bootstrap, SEO and GitHub Pages.

| No. | Experiment | Folder |
|-----|------------|--------|
| 1 | GitHub Repository and GitHub Pages | [Open](Web-Design-Experiment-1/) |
| 2 | Personal Portfolio Webpage | [Open](Web-Design-Experiment-2/) |
| 3 | Dynamic To-Do List | [Open](Web-Design-Experiment-3/) |
| 4 | SEO and Accessibility Optimized Page | [Open](Web-Design-Experiment-4/) |
| 5 | Weather App | [Open](Web-Design-Experiment-5/) |
| 6 | Responsive Blog Website | [Open](Web-Design-Experiment-6/) |

Live site (after enabling GitHub Pages): `https://YOUR-USERNAME.github.io/web-development-lab/Web-Design-Experiment-1/`
