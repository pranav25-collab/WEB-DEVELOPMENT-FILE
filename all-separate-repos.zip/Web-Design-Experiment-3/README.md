# Web Design Experiment 3: Dynamic To-Do List

Add, delete and mark tasks as completed using JavaScript and DOM manipulation.

## Files
- `index.html` - HTML, CSS, JavaScript in one file

## Run locally
Open `index.html` in a web browser (or use the Live Server extension in VS Code).
