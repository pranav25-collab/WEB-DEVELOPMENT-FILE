# Web Design Experiment 6: Responsive Blog Website

Blog layout using Bootstrap and media queries.

## Files
- `index.html` - HTML, CSS in one file

## Run locally
Open `index.html` in a web browser (or use the Live Server extension in VS Code).
