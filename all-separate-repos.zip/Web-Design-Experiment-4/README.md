# Web Design Experiment 4: SEO and Accessibility Optimized Page

Semantic HTML, proper heading structure and meta tags.

## Files
- `index.html` - HTML, CSS in one file

## Run locally
Open `index.html` in a web browser (or use the Live Server extension in VS Code).
