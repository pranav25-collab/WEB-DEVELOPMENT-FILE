# Web Design Experiment 5: Weather App

Fetches real-time weather for a city using the Fetch API (Open-Meteo, no API key needed).

## Files
- `index.html` - HTML, CSS, JavaScript in one file

## Run locally
Open `index.html` in a web browser (or use the Live Server extension in VS Code).
