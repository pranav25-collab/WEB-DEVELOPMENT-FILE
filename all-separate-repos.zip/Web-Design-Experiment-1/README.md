# Web Design Experiment 1: GitHub Repository and GitHub Pages

A simple static website hosted with GitHub Pages.

## Files
- `index.html` - HTML, CSS in one file

## Run locally
Open `index.html` in a web browser (or use the Live Server extension in VS Code).
