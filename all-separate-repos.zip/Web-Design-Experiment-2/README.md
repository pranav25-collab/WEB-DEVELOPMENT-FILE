# Web Design Experiment 2: Personal Portfolio Webpage

Portfolio page with navigation menu, about section, projects section and contact form (HTML + CSS).

## Files
- `index.html` - HTML, CSS in one file

## Run locally
Open `index.html` in a web browser (or use the Live Server extension in VS Code).
